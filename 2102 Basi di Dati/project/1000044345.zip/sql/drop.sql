
DROP DATABASE CentroAdozioneAnimali;
