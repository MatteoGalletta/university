/*
 * graphic.cpp
 */
 
#include "graphic.h"

bool Frame::checkClick(int mouse_x, int mouse_y)
{
	return (mouse_x >= x) && (mouse_x <= x + width) && (mouse_y >=y) && (mouse_y <= y + height);
}


ostream& operator<<(ostream& out, Frame & f)
{
	out << "(" << f.x << "," << f.y << "," << f.width << "," << f.height << ")" ;
	return out;
}

ostream& operator<<(ostream& out, Checkbox & c)
{
	out << c.text << "[" << c.status << "]" << "(" << c.x << "," << c.y << "," << c.width << "," << c.height << ")";
	return out;

}

ostream& operator<<(ostream& out, Window & w)
{
	out << w.text << "(" << w.x << "," << w.y << "," << w.width << "," << w.height << ")";
	return out;

}


void Window::onClick(int mouse_x, int mouse_y)
{
	for (vector<Frame *>::iterator it = items.begin(); it != items.end(); it++) {
		Frame * f = (Frame *)(*it);
		if (f->checkClick(mouse_x, mouse_y))
			f->onClick(mouse_x, mouse_y);
	}
}


