/*
 * test_graphic.cpp
 */
#include "graphic.h"

int main(int argc, char ** argv)
{

	Window w(0,0, 100, 100, "Hello");
	
	cout << w << endl;
	
	Checkbox * check1 = new Checkbox(10,10,60,10, "Check 1");
	Checkbox * check2 = new Checkbox(10,30,60,10, "Check 2");

	w += check1;
	w += check2;
	
	cout << (*check1) << endl;
	cout << (*check2) << endl;
	
	w.onClick(60, 50);
	cout << "---------------------" << endl;
	cout << (*check1) << endl;
	cout << (*check2) << endl;
	
	w.onClick(15, 15);
	cout << "---------------------" << endl;
	cout << (*check1) << endl;
	cout << (*check2) << endl;
	
	w.onClick(15, 35);
	cout << "---------------------" << endl;
	cout << (*check1) << endl;
	cout << (*check2) << endl;
	
	w.onClick(15, 15);
	cout << "---------------------" << endl;
	cout << (*check1) << endl;
	cout << (*check2) << endl;
	
	return 0;
}

