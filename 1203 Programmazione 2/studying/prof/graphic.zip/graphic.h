/*
 * graphic.h
 */
 
#include <iostream>
#include <string>
#include <vector>

using namespace std;
 
class Frame {
protected:
	int x,y,width,height;
public:
	Frame(int _x, int _y, int _w, int _h) :
		x(_x), y(_y), width(_w), height(_h) { };
	virtual void onClick(int mouse_x, int mouse_y) = 0;
	
	bool checkClick(int mouse_x, int mouse_y);
	
	friend ostream& operator<<(ostream& out, Frame & f);
};

ostream& operator<<(ostream& out, Frame & f);


class Checkbox : public Frame {
	bool status;
	string text;
public:
	Checkbox(int _x, int _y, int _w, int _h, string _text) :
		Frame(_x, _y, _w, _h),
		status(false),
		text(_text) { };
		
	void onClick(int mouse_x, int mouse_y) {
		status = !status;
	}; 
	friend ostream& operator<<(ostream& out, Checkbox & c);
};

ostream& operator<<(ostream& out, Checkbox & c);

class Window : public Frame
{
	string text;
	vector<Frame *> items;	
public:
	Window(int _x, int _y, int _w, int _h, string _text) :
		Frame(_x, _y, _w, _h),
		text(_text) { };
	Window & operator+=(Frame * f) {
		items.push_back(f);
		return *this;
	};
	void onClick(int mouse_x, int mouse_y);
	friend ostream& operator<<(ostream& out, Window & w);
};

ostream& operator<<(ostream& out, Window & w);

