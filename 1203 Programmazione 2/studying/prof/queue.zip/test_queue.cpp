/*
 * test_queue.cpp
 */
 
#include <iostream>
#include <string>
#include "queue.h"

using namespace std;

class Studente {
	string matricola;
	string nome;
	string cognome;
public:
	Studente() : matricola(""), nome(""), cognome("") {};
	
	Studente(string _matricola, string _nome = "", string _cognome = "") :
		matricola(_matricola), nome(_nome), cognome(_cognome) {};
		
	Studente(Studente & p) :
		matricola(p.matricola), nome(p.nome), cognome(p.cognome) {};
		
	bool operator==(Studente & rhs) {
		return (matricola == rhs.matricola);
	};
	
	bool operator<(Studente & rhs) {
		// true se this < rhs
		// false negli altri casi
		// (ordinamento solo su nome e cognome)
		if (cognome < rhs.cognome) return true;
		if (cognome == rhs.cognome) {
			if (nome < rhs.nome) return true;
		}
		return false;
	};
	
	friend ostream& operator<<(ostream& out, const Studente & p);
};

ostream& operator<<(ostream& out, const Studente & p)
{
	out << "(" << p.matricola << "," << p.nome << "," << p.cognome << ")";
	return out;
}

int main(int argc, char **argv)
{
	Queue<Studente> mylist;
	
	mylist.put(Studente("10001", "Mario", "Rossi"));
	mylist.put(Studente("10002", "Giuseppe", "Verdi"));
	mylist.put(Studente("10003", "Salvatore", "Bianchi"));
	mylist.put(Studente("10004", "Giuseppe", "Rossi"));
	
	//mylist.show();
	//cout << endl;

	for (;;) {
		Studente s = mylist.get();
		cout << s << endl;
	}
		
	return 0;
}

