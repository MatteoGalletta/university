/*
 * queue.h
 */

#ifndef __QUEUE_H
#define __QUEUE_H

#include <iostream>

class QueueEmptyException { };

template <typename T> class Queue {
	T elem;
public:
	Queue() : next(nullptr), tail(this) { };
	Queue(T e) : elem(e),next(nullptr),tail(this) { };
	void put(T data) {
		Queue<T> * nuovo_nodo = new Queue<T>(data);
		tail->next = nuovo_nodo;
		tail = nuovo_nodo;
	
	};
	T get() {
		if (this == tail) {
			// non posso fare il pop
			throw QueueEmptyException();
		}
		Queue<T> * first = this->next;	
		Queue<T> * new_first = first->next;
		T temp = first->elem;
		if (first->next == nullptr) {
			// ultimo elemento in coda
			tail = this;
		}
		delete first;
		this->next = new_first;
		return temp;
	};
	void show(std::ostream & output = std::cout) {
		Queue<T> * p = this->next;
		while (p != nullptr) {
			output << p->elem << std::endl;
			p = p->next;
		}
	};

	Queue<T> * next, * tail;
};

#endif

