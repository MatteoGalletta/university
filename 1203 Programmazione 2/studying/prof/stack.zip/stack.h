/*
 * stack.h
 */

#ifndef __STACK_H
#define __STACK_H

#include <iostream>

class StackEmptyException { };

template <typename T> class Stack {
	T elem;
public:
	Stack() : next(nullptr) { };
	Stack(T e) : elem(e),next(nullptr) { };
	T get() { return elem; };
	void push(T data) {
		Stack<T> * nuovo_nodo = new Stack<T>(data);
		nuovo_nodo->next = this->next;
		this->next = nuovo_nodo;
	};
	T pop() {
		Stack<T> * first = this->next;	
		if (first == nullptr) {
			// non posso fare il pop
			throw StackEmptyException();
		}
		Stack<T> * new_first = first->next;
		T temp = first->elem;
		delete first;
		this->next = new_first;
		return temp;
	};
	void show(std::ostream & output = std::cout) {
		Stack<T> * p = this->next;
		while (p != nullptr) {
			output << p->get() << std::endl;		
			p = p->next;
		}
	};

	Stack<T> * next;
};

#endif

