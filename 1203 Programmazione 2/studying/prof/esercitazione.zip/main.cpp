/*
 * main.cpp
 */
 
#include <iostream>
#include <fstream>
#include <map>
#include "student.h"
#include "bst.h"
#include "list.h"

using namespace std;

ostream& operator<<(ostream& out, t_student & st)
{
	out << st.matricola << "," << st.cognome << "," << st.nome << "," << st.citta << "," << st.media_voti;
	return out;
}

class OutputVisitor : public StudentVisitor {
public:
	void on_data(t_student s) { cout << s << endl; };
};

class MaxComputer : public StudentVisitor {
	t_student temp_max;
public:
	MaxComputer(t_student m) : StudentVisitor(), temp_max(m) { };
	t_student & get() { return temp_max; };
	void on_data(t_student s) {
		if (s.media_voti > temp_max.media_voti)
			temp_max = s;
	};
};

class ListCopier : public StudentVisitor {
	List * l;
public:
	ListCopier(List * _l) : StudentVisitor(), l(_l) { };
	void on_data(t_student s) {
		l->insert_in_order(s);
	};
};

typedef map<string, List> t_city_map;

class MapCreator : public StudentVisitor {
	t_city_map * cm;
public:
	MapCreator(t_city_map * m) : StudentVisitor(), cm(m) { };
	void on_data(t_student s) {
		if (cm->contains(s.citta)) {
			(*cm)[s.citta].insert(s);
		}
		else {
			List l;
			l.insert(s);
			(*cm)[s.citta] = l;
		}
	};
};


void read_file(string filename, BST & bst)
{
	ifstream file;
	t_student st;
	
	file.open(filename);
	
	file >> st.matricola >> st.cognome >> st.nome >> st.citta >> st.media_voti;
	
	while (file.good()) {
		bst.insert(st);		
		file >> st.matricola >> st.cognome >> st.nome >> st.citta >> st.media_voti;
	} 
	file.close();
}


int main(int argc, char *argv[])
{
	BST mybst;
	read_file("studentiCitta.txt", mybst);
	
	OutputVisitor * o = new OutputVisitor();
	//mybst.show();
	mybst.visit(o);
	
	MaxComputer * m = new MaxComputer(mybst.get_root_element());
	//mybst.max_voti(s);
	mybst.visit(m);
	cout << "Lo studente con la media piu' alta e' " << m->get() << endl;
	
	List l;
	ListCopier * lc = new ListCopier(&l);
	//mybst.copy(l);
	mybst.visit(lc);
	
	l.visit(o);
	
	t_city_map city_map;
	MapCreator * mc = new MapCreator(&city_map);	
	l.visit(mc);
	
	for (t_city_map::iterator it = city_map.begin(); it != city_map.end(); it++) {
		string city = it->first;
		cout << "Citta' : " << city << " -- Studenti " << it->second.get_count() << endl;
		it->second.visit(o);
		cout << "-------------------------------------------------------------" << endl;
	}
	
	return 0;
}

