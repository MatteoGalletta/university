/*
 * bst.h
 */

#ifndef __BST_H
#define __BST_H

#include "student.h"

class BST {
	BST * root;
	
	t_student data;
	BST * left;
	BST * right;
	
	void _insert(BST * & p, t_student st);
	void _visit(BST * p, StudentVisitor * dest);
public:
	BST() : root(nullptr), left(nullptr), right(nullptr) { };
	BST(t_student st) : root(nullptr), data(st), left(nullptr), right(nullptr) { };
	void insert(t_student st);
	t_student get_root_element() { return root->data; };
	
	void visit(StudentVisitor * dest);
};


#endif

