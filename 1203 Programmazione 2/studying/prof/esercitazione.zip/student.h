/*
 * student.h
 */

#ifndef __STUDENT_H
#define __STUDENT_H
 
#include <string>
#include <iostream>
 
typedef struct {
	std::string matricola;
	std::string cognome;
	std::string nome;
	std::string citta;
	float  media_voti;
} t_student;

std::ostream& operator<<(std::ostream& out, t_student & st);

class StudentVisitor {
public:
	StudentVisitor() { }
	virtual void on_data(t_student s) = 0;
};


#endif

