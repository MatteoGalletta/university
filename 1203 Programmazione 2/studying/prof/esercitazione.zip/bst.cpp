/*
 * bst.cpp
 */

#include <iostream>
#include "bst.h"

using namespace std;

void BST::insert(t_student st)
{
	_insert(root, st);
}

void BST::_insert(BST * & p, t_student st)
{
	if (p == nullptr) {
		p = new BST(st);
	}
	else {
		if (st.matricola > p->data.matricola)
			_insert(p->right, st);
		else if (st.matricola < p->data.matricola)
			_insert(p->left, st);
	}
}

void BST::visit(StudentVisitor * dest)
{
	_visit(root, dest);
}

void BST::_visit(BST * p, StudentVisitor * dest)
{
	if (p != nullptr) {
		_visit(p->left, dest);
		dest->on_data(p->data);
		_visit(p->right, dest);
	}
}



