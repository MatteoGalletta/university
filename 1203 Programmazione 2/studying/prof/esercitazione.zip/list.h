/*
 * list.h
 */

#ifndef __LIST_H
#define __LIST_H

#include "student.h"

class List {

	List * first;
	t_student data;
	List * next;
	int count;
	void _insert_in_order(List * & p, t_student s);

public:
	List() : first(nullptr), next(nullptr), count(0) { };
	List(t_student s) : first(nullptr), data(s), next(nullptr) { };
	void insert(t_student s);
	void insert_in_order(t_student s);
	void visit(StudentVisitor * sv);
	
	int get_count() { return count; };
};

#endif

