/*
 * list.cpp
 */
 
#include <iostream>
#include "list.h"

using namespace std;

void List::insert(t_student s)
{
	List * p = new List(s);
	p->next = first;
	first = p;
	++count;
}

void List::insert_in_order(t_student s)
{
	_insert_in_order(first, s);
	++count;
}

void List::_insert_in_order(List * & p, t_student s)
{
	if (p == nullptr) {
		p = new List(s);
	}
	else {
		if (p->data.cognome < s.cognome)
			_insert_in_order(p->next, s);
		else {
			List * new_node = new List(s);
			new_node->next = p;
			p = new_node;
		}
	}
}

void List::visit(StudentVisitor * sv)
{
	List * p = first;
	while (p != nullptr) {
		sv->on_data(p->data);
		p = p->next;
	}
}

